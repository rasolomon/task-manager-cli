package com.example.taskmanager.service;

import com.example.taskmanager.model.Task;
import java.util.ArrayList;
import java.util.List;

public class TaskService {

    private List<Task> tasks = new ArrayList<>();

    public void addTask(Task task ) {
        tasks.add(task);
    }
    public void removeTask(int taskId) {
        List<Task> tempTasks = tasks;
        for (Task task : tempTasks) {
            if (task.getId() == taskId) {
                tempTasks.remove(task);
                break;
            }
        }
        tasks = tempTasks;
    }
    public List<Task>  getAllTasks() {
        return tasks;
    }

    public void completeTask(int taskId) {
        for (Task task : tasks) {
            if (task.getId() == taskId) {
                task.markCompleted();
            }
        }
    }

    public Task findTaskById(int taskId) {
        for (Task task : tasks) {
            if (task.getId() == taskId) {
                return task;
            }
        }
        return null;
    }
}